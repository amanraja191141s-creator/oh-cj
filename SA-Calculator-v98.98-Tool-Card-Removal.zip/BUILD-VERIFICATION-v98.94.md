# SA Calculator v98.94 — Build verification

| Check | Result |
|---|---:|
| App version | `1.99.08-v98.94` |
| Android versionCode | `1099114` |
| Automated tests | **161 passed / 0 failed** |
| Calculator tool screens | **19 / 19 present** |
| Static card surfaces under audited selectors | **68** |
| HTML IDs | **316 unique / 0 duplicates** |
| YAML parse | **22 / 22** (after adding v98.94 standalone YAML) |
| Workflow/YAML copies byte-identical | **22 / 22** |
| Package test paths | **29 present / 0 missing** |
| Android web assets | **13 verified** |
| Root/`www` parity | **8 / 8** |
| JavaScript syntax | **Passed** |
| ZIP integrity | **Passed** |

## Important limits

The browser screenshot rendering and physical Android device were not validated. Exact on-screen pixel alignment, touch/scroll behaviour on different Android densities, APK build/signing and remote GitHub Actions execution remain pending. The 430px value is a CSS-pixel maximum; on a narrower viewport the card width intentionally becomes the available width.

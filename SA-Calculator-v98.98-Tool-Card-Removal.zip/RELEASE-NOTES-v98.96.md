# SA Calculator v98.96 — Content-first tool card correction

- Fixed the cross-tool field compression visible in the 2026-11-24 Android recordings.
- Removed the global 64px height cap that overrode compound input/result layouts.
- Restored per-tool GST, finance, BMI and currency card dimensions.
- Retained responsive 430px maximum card width without forcing card height or nested vertical scrolling.
- Added regression tests for content geometry and source/Android web asset parity.
- Bumped app version to `1.99.10-v98.96` and Android versionCode to `1099116`.
- Updated the service-worker cache namespace to invalidate v98.95 cached CSS.

# SA Calculator v98.90 — Build Verification

- Release: `1.99.06-v98.92`
- Android versionCode: `1099111`
- Cache namespace: `sa-calculator-v98-92-gst-rate-position-placeholder-preset-v9892`

## Local checks
- `npm test`: 133 passed, 0 failed.
- `node --check assets/js/app.js`: passed.
- `node --check assets/js/localization.js`: passed.
- `node --check assets/js/theme-bootstrap.js`: passed.
- `node --check service-worker.js`: passed.
- `node scripts/prepare-android-web.mjs`: passed; 13 required assets verified.
- Root and `www/` copies: 8/8 byte-identical.
- Workflow YAML: 12 copies parsed and byte-identical.
- Release test entry points: 24/24 exist.
- ZIP archive: `unzip -t` passed.

## Not run
- GitHub Actions remote workflow.
- Android Gradle/APK build.
- Physical Android WebView/device interaction and performance test.
- Browser screenshot automation was attempted, but navigation was blocked by the execution environment's browser policy; visual verification therefore remains a device/CI task.

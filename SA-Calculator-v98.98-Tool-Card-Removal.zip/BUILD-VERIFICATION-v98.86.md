# Build verification — v98.86

- Release: `1.99.00-v98.86`
- Android versionCode: `1099106`
- Service-worker cache: `sa-calculator-v98-86-gst-action-layout-caret-v9886`
- Automated tests: 120 passed / 0 failed
- JavaScript syntax checks: passed
- Android web preparation: passed (13 required assets)
- Workflow YAML: 6 files parsed, all byte-identical
- Release test entry points: 21 present
- Root/`www/` bundle sync: 8 files byte-identical
- ZIP integrity: verified after packaging

No APK was built, no physical Android device was available for runtime validation, and no remote GitHub Actions workflow was executed.

# SA Calculator v98.90 — GST row and caret correction

- Places 5% and 18% quick rates directly beside the Add rate input in one row.
- Keeps GST Rate and Original Amount cards at equal outer dimensions.
- Fixes the placeholder pseudo-element bug that left `Enter amount` / `Add rate` visible after typing.
- Keeps only the selected GST field's caret active.
- Adds horizontal input scrolling that follows the caret for long values.
- Preserves comma-aware caret mapping, keypad insertion/deletion, quick-rate selection and GST calculations.
- Adds dedicated regression coverage for the supplied recording's defects.

Release identity: `1.99.06-v98.92` / Android versionCode `1099111`.

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const tools=['currencies','units','discount','percent','salestax','agecalc','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','salary','savings','sip','tip','unitprice','worldtime'];
test('all 19 calculator tools remain present',()=>{ for(const id of tools) assert.match(html,new RegExp(`id=\"screen-${id}\"`)); });
test('all shared calculator card families remain styled',()=>{
 for(const selector of ['.calc-card','.result-card','.reference-form-card','.reference-result-card','.bmi-reference-field-card','.gst-reference-card','.gst-result-card','.gpa-result-card','.loan-video-result-card','.loan-video-field','.savings-field','.date-difference-card','.date-difference-result','.date-event-card','.world-clock-card','.reference-world-hero','.reference-unit-card','.unit-price-card','.currency-reference-field','.discount-reference-row','.hex-convert-row','.world-clock-row','.world-base-card']) assert.ok(css.includes(selector),`missing card family ${selector}`);
});
test('per-tool compound fields retain their authored content dimensions',()=>{
 assert.match(css,/#screen-salestax \.gst-reference-card[\s\S]*?min-height:145px !important/);
 assert.match(css,/#screen-currencies \.currency-reference-field[\s\S]*?height:122px !important/);
 assert.match(css,/#screen-bodymetrics \.bmi-reference-field-card[\s\S]*?min-height:145px !important/);
});
test('tool field and caret contracts remain in place',()=>{
 assert.match(css,/input-val-box\[data-tool-field=\"true\"\]/);
 assert.match(css,/input-cursor/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));

test('v98.73 release identity is synchronized',()=>{
  const expected='1.99.12-v98.98';
  assert.equal(pkg.version,expected); assert.equal(pkg.androidVersionCode,1099118);
  assert.ok(html.includes(expected)); assert.ok(js.includes(`const APP_VERSION = '${expected}'`));
  assert.equal(JSON.parse(fs.readFileSync('manifest.webmanifest','utf8')).version,expected);
  assert.match(fs.readFileSync('service-worker.js','utf8'),/sa-calculator-v98-98-tool-form-cardless-v9898/);
});

test('all reference numeric tool fields share Loan card geometry tokens',()=>{
  for(const token of ['--sa-field-height:88px','border-radius:22px','border:2px solid','--sa-field-icon:50px','--sa-field-gap:12px','screen-currencies','screen-units','screen-discount','screen-percent','screen-salestax','screen-bodymetrics','screen-agecalc','screen-savings','screen-salary','screen-sip','screen-tip']) assert.ok(css.includes(token),`missing ${token}`);
  assert.match(css,/#screen-viewport #screen-currencies \.currency-parity-card/);
});

test('Currency converter uses shared cards, searchable picker and readonly result field',()=>{
  assert.match(html,/id="cur-from"/); assert.match(html,/id="cur-to"/);
  assert.match(html,/id="cur-amount"/); assert.match(html,/id="cur-to-amount"[^>]*aria-readonly="true"/);
  assert.match(js,/inputElem\.getAttribute\('aria-readonly'\) === 'true' \|\| inputElem\.id === 'cur-to-amount'/);
  assert.match(js,/function openPicker\(select\)[\s\S]*?closeToolKeypad\(\)/);
});

test('Currency keypad uses a swap action and keeps converter live',()=>{
  assert.match(js,/if \(STATE\.currentScreen === 'units'\)/);
  assert.match(js,/if \(STATE\.currentScreen === 'currencies'\) \{[\s\S]*?recalculateCurrentScreen\(\)/);
  assert.match(js,/btn-cur-swap/);
  assert.match(js,/candidate = val\.slice\(0, caret\) \+ inserted/);
  assert.match(js,/Currency conversion is live/);
});

test('all 12 requested tools remain registered in the UI',()=>{
  for(const id of ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics']) assert.ok(html.includes(`id="screen-${id}"`),`${id} screen missing`);
});

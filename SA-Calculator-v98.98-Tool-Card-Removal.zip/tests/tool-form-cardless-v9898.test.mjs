import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p,'utf8');
test('v98.98 flattens redundant tool form wrappers only',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.ok(css.includes('v98.98 — flatten outer tool form cards'));
 assert.ok(css.includes('.calc-card:not(.settings-card)'));
 assert.ok(css.includes('.reference-form-card'));
 assert.ok(css.includes(':not(#screen-tools):not(#screen-settings)'));
});
test('tools catalogue and interactive fields remain present',()=>{
 const html=read('index.html');
 const css=read('assets/css/tool-reference-ui.css');
 assert.ok(html.includes('class="premium-tool-card"'));
 assert.ok(html.includes('class="input-val-box'));
 assert.ok(css.includes('.input-val-box'));
});
test('source and web stylesheet stay identical',()=>assert.equal(read('assets/css/tool-reference-ui.css'),read('www/assets/css/tool-reference-ui.css')));
test('release identity and cache namespace are synchronized',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.99.12-v98.98');
 assert.equal(pkg.androidVersionCode,1099118);
 assert.ok(read('service-worker.js').includes('sa-calculator-v98-98-tool-form-cardless-v9898'));
 assert.ok(read('index.html').includes('1.99.12-v98.98'));
});
